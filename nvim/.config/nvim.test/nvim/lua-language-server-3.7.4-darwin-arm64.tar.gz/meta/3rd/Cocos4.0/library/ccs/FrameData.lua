---@meta

---@class ccs.FrameData :ccs.BaseData
local FrameData = {}
ccs.FrameData = FrameData

---*
---@param baseData ccs.BaseData
---@return self
function FrameData:copy(baseData) end
---*
---@return self
function FrameData:create() end
---* js ctor
---@return self
function FrameData:FrameData() end
